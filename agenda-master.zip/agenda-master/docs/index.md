---
title: Agenda — Lightweight job scheduling for Node.js
---

* [Changelog](https://github.com/agenda/agenda/blob/master/History.md#readme)
* [Volunteer chat on Slack](https://slackin-ekwifvcwbr.now.sh/)
* [Issues](https://github.com/agenda/agenda/issues)

## Documentation

- [v4.0.1](./agenda/4.0.1)
- [v3.1.0](./agenda/3.1.0)
- [v2.2.0](./agenda/2.2.0)
- [v2.0.0](./agenda/2.0.0)
- [v1.0.3](./agenda/1.0.3)
