// old common js export (see index.ts for module exports)

import { Agenda } from "./agenda";
module.exports = Agenda;
module.exports.Agenda = Agenda;
